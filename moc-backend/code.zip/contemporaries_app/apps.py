from django.apps import AppConfig


class ContemporariesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'contemporaries_app'
